<?php
	$serverName = "DESKTOP-E9C1KDP";
	$connectionInfo = array( "Database"=>"admonmc");
	$conn = sqlsrv_connect( $serverName, $connectionInfo);
?>